package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"syscall"

	"github.com/kardianos/service"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"golang.org/x/sys/windows/registry"
	"gopkg.in/natefinch/lumberjack.v2"
	"gopkg.in/yaml.v2"
)

// variable con el nombre de la carpeta de ScannerDoc
const scannerDocFolderName string = "ScannerDoc"

// variable global de log para utilizarlo en cualquiera de nuestras funciones
var log *logrus.Logger

// Crear una estructura para almacenar la configuración
var config *Config

type Config struct {
	HTTP    HTTPConfig    `yaml:"tLShttp"`
	Folders FoldersConfig `yaml:"folders"`
	Paths   PathsConfig   `yaml:"paths"`
}

type HTTPConfig struct {
	HTTPPort string `yaml:"httpPort"`
	CertFile string `yaml:"certFile"`
	KeyFile  string `yaml:"keyFile"`
}

type FoldersConfig struct {
	ScannerDoc   string `yaml:"scannerDoc"`
	Certificates string `yaml:"certificates"`
	JavaVersion  string `yaml:"javaVersionFolder"`
}

type PathsConfig struct {
	PatResources        string `yaml:"patResources"`
	JarPath             string `yaml:"jarPath"`
	JarPathDependencies string `yaml:"jarPathDependencies"`
	ProgramFilesx86or64 string `yaml:"programFilesx86or64Path"`
	ProgramData         string `yaml:"programDataPath"`
}

type ScannerDocData struct {
	ScannerDoc []string `json:"scannerDoc"`
}

// ErrorResponse representa la estructura JSON para los mensajes de error
type ErrorResponse struct {
	Error string `json:"Error"`
}

type program struct {
	service service.Service
}

type myService struct {
	log        *logrus.Logger
	logFile    *lumberjack.Logger
	stopCh     chan struct{}
	httpServer *http.Server
}

func (s *myService) Start(svc service.Service) error {
	s.stopCh = make(chan struct{})
	err := s.setupLogger()
	if err != nil {
		return err
	}

	// Inicia el servidor HTTP aquí
	go s.run()
	return nil
}

func (s *myService) setupLogger() error {

	viper.SetConfigName("configLog")
	viper.SetConfigType("yaml")
	viper.AddConfigPath(filepath.Join(os.Getenv("ProgramData"), scannerDocFolderName+"\\AgentScannerDoc\\config"))

	//viper.Debug()
	err := viper.ReadInConfig()
	if err != nil {
		return err
	}

	s.log = logrus.New()

	s.logFile = &lumberjack.Logger{
		Filename:   getConfigString("log.file.filename"),
		MaxSize:    getConfigInt("log.file.maxSize"),    // MB
		MaxBackups: getConfigInt("log.file.maxBackups"), // Max number of backups
		MaxAge:     getConfigInt("log.file.maxAge"),     // Days
		Compress:   getConfigBool("log.file.compress"),
	}

	s.log.SetOutput(s.logFile)

	// Configurar el nivel de log
	level, err := logrus.ParseLevel(getConfigString("log.level"))
	if err != nil {
		s.log.WithError(err).Fatal("Error al configurar el nivel de log")
	}

	s.log.SetLevel(level)

	// Formato del log en formato JSON para logs estructurados
	s.log.SetFormatter(&logrus.JSONFormatter{})

	return nil
}

func (s *myService) run() {
	s.log.Info("Service running...")

	//load file properties
	loadFileProperties(s)

	s.initHTTPServer()
	<-s.stopCh
}

func (s *myService) initHTTPServer() {
	// Inicializa el servidor HTTP aquí
	port := config.HTTP.HTTPPort
	certFile := config.HTTP.CertFile
	keyFile := config.HTTP.KeyFile

	http.HandleFunc("/scannerDoc", s.handlerScannerDoc)
	http.HandleFunc("/scannerUnjam", s.handlerScannerUnjam)

	s.httpServer = &http.Server{
		Addr:    ":" + port,
		Handler: nil, // Usa nil para el enrutador predeterminado (http.DefaultServeMux)
	}

	go func() {
		if err := s.httpServer.ListenAndServeTLS(certFile, keyFile); err != nil {
			s.log.WithError(err).Fatal(err)
		}
	}()
}

func (s *myService) Stop(svc service.Service) error {
	close(s.stopCh)
	s.log.Info("Stopping service...")
	if s.logFile != nil {
		err := s.logFile.Close()
		if err != nil {
			s.log.WithError(err).Error("error al cerrar archivo log")
		}
	}

	// Detener el servidor HTTP
	if s.httpServer != nil {
		if err := s.httpServer.Shutdown(nil); err != nil {
			s.log.WithError(err).Error("Error al detener el servidor HTTP")
		}
	}

	// Realiza cualquier limpieza necesaria antes de detener el servicio
	return nil
}

func (s *myService) handlerScannerDoc(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	searchString := "scannerdoc"
	err := getJavaProcessIDs(searchString)

	if err != nil {
		s.handleError(w, fmt.Errorf("%s", err))
		return
	}

	requiredParams := []string{"deviceName", "fileType", "docSource", "imgType", "resolution", "docSize", "docRotate", "brightness", "contrast", "threshold", "colorFilter", "numScan"}

	//bucle para verificar que todos los parametros esten completos
	for _, param := range requiredParams {
		value := r.URL.Query().Get(param)
		if value == "" {
			s.handleError(w, fmt.Errorf("el parámetro %s es requerido", param))
			return
		}
	}

	// get parameters
	queryParams := r.URL.Query()
	deviceName := queryParams.Get("deviceName")
	fileType := queryParams.Get("fileType")
	docSource := queryParams.Get("docSource")
	imgType := queryParams.Get("imgType")
	resolution := queryParams.Get("resolution")
	docSize := queryParams.Get("docSize")
	docRotate := queryParams.Get("docRotate")
	brightness := queryParams.Get("brightness")
	contrast := queryParams.Get("contrast")
	threshold := queryParams.Get("threshold")
	colorFilter := queryParams.Get("colorFilter")
	numScan := queryParams.Get("numScan")
	isMock := queryParams.Get("isMock")

	if isMock == "" {
		isMock = "false"
	}

	// JAR file arguments
	jarArgs := []string{deviceName, fileType, docSource, imgType, resolution, docSize, docRotate, brightness, contrast, threshold, colorFilter, numScan, isMock}

	// Path to the Java executable
	javaPathFolder, errjava := getJavaForlderPath()
	if errjava != nil {
		s.handleError(w, fmt.Errorf("%w", errjava))
		return
	}

	javaPath := javaPathFolder + "\\bin\\java.exe"

	if directoryNoExists(config.Paths.PatResources) {
		s.handleError(w, fmt.Errorf("el directorio %s no existe", config.Paths.PatResources))
		return
	}

	cmdArgs := []string{"-jar", config.Paths.PatResources + config.Paths.JarPath}
	cmdArgs = append(cmdArgs, jarArgs...)
	cmd := exec.Command(javaPath, cmdArgs...)

	//run with hide window of java
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true,
	}

	// Capture the command's output and error
	output, err := cmd.CombinedOutput()

	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}
	//validamos si en la variable de salida de la ejecucion del jar hay algun error
	if strings.Contains(string(output), "\"Error\"") {
		s.handleError(w, fmt.Errorf("%s", getTextInsideError(string(output))))
	} else {
		// Create a struct with the desired JSON structure
		data := getTextInsideScannerDoc(string(output))
		// Convert the result struct to JSON
		jsonData, err := json.Marshal(data)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
		}
		// Set the response headers
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)

		// Write the JSON response
		_, err = w.Write(jsonData)
		if err != nil {
			s.log.Println(err)
		}
	}

}

func enableCors(w *http.ResponseWriter) {
	(*w).Header().Set("Access-Control-Allow-Origin", "*")
	(*w).Header().Set("Access-Control-Allow-Methods", "GET")
	(*w).Header().Set("Access-Control-Allow-Headers", "Content-Type")
}

func directoryNoExists(directoryPath string) bool {
	info, err := os.Stat(directoryPath)
	if os.IsNotExist(err) {
		return true // El directorio no existe
	}
	if err != nil {
		return true
	}
	return !info.IsDir()
}

// cargar archivo de propiedades desde ScannerDocFolder in Program Data
func loadFileProperties(s *myService) {
	// Leer el contenido del archivo de configuración
	data, err := ioutil.ReadFile(filepath.Join(os.Getenv("ProgramData"), scannerDocFolderName+"\\AgentScannerDoc\\config\\StartAgentScannerDocProperties.yaml"))
	if err != nil {
		s.log.WithError(err).Fatal("Error al leer el archivo de configuración")
	}
	// Decodificar el archivo YAML en la estructura
	err = yaml.Unmarshal(data, &config)
	if err != nil {
		s.log.WithError(err).Fatal("Error al decodificar el archivo YAML")
	}
}

func (s *myService) handleError(w http.ResponseWriter, err error) {
	s.log.WithError(err).Error("Error interno del servidor")
	// Cast the error to string
	errorString := err.Error()
	// Crear una estructura ErrorResponse
	errorResponse := ErrorResponse{
		Error: errorString,
	}

	// Convert the result struct to JSON
	jsonData, err := json.Marshal(errorResponse)
	if err != nil {
		s.log.WithError(err).Error("Error interno del servidor")
	}

	// Serializar la estructura a JSON y escribir en el cuerpo de la respuesta
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusInternalServerError)
	w.Write(jsonData)
}

/*
	func (s *myService) errorHandler(handler func(http.ResponseWriter, *http.Request) error) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			if r.Method == http.MethodOptions {
				// Configurar los encabezados CORS para las solicitudes OPTIONS
				w.Header().Set("Access-Control-Allow-Origin", "*")
				w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
				w.Header().Set("Access-Control-Allow-Headers", "Origin,Content-Type")
				w.Header().Set("Access-Control-Max-Age", "2147483647")
				w.WriteHeader(http.StatusOK)
				return
			}
			w.Header().Set("Access-Control-Allow-Origin", "*")
			w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "Origin,Content-Type")
			w.Header().Set("Access-Control-Max-Age", "2147483647")
			err := handler(w, r)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				//se guarda en el log
				s.log.WithError(err).Error("Error en el handler")
			}
		}
	}
*/
func getTextInsideError(completeString string) string {
	// regexp
	re := regexp.MustCompile(`"Error"\s*:\s*"([^"]+)"`)

	// Buscar coincidencias en la cadena
	matches := re.FindStringSubmatch(completeString)

	// Verificar si se encontraron coincidencias
	if len(matches) > 1 {
		//return matches[1]
		return sanitizeJSONString(matches[1])
	} else {
		return completeString
	}

}

func getTextInsideScannerDoc(completeString string) ScannerDocData {
	// regexp
	re := regexp.MustCompile(`\{([^{}]+)\}`)
	match := re.FindString(completeString)

	var data ScannerDocData
	err := json.Unmarshal([]byte(match), &data)
	if err != nil {
		return data
	}
	// Verificar si se encontraron coincidencias
	return data
}

func sanitizeJSONString(jsonStr string) string {
	jsonStr = strings.Replace(jsonStr, "\"", "", -1)
	jsonStr = strings.Replace(jsonStr, "\n", "", -1)
	jsonStr = strings.Replace(jsonStr, "\tError:", "", -1)
	// Remover las comillas al inicio y al final del valor de Fingerprint
	jsonStr = strings.Trim(jsonStr, "\"")

	return jsonStr
}

func getJavaForlderPath() (string, error) {
	// obtiene el java path si existe en la ProgramFilesx86or64
	javaPath := filepath.Join(os.Getenv(config.Paths.ProgramFilesx86or64), "Java")

	// Verifica si el directorio existe
	_, err := os.Stat(javaPath)
	if err != nil {
		if os.IsNotExist(err) {
			return "", fmt.Errorf("no tienes una instalación de Java  en la carpeta" + os.Getenv(config.Paths.ProgramFilesx86or64))
		}
		return "", fmt.Errorf("error al verificar la existencia de la instalación de Java: %s", err)
	}

	var javaVersionFolder string
	err = filepath.Walk(javaPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() && strings.Contains(info.Name(), config.Folders.JavaVersion) {
			javaVersionFolder = path
			return filepath.SkipDir
		}
		return nil
	})

	if err != nil {
		return "", fmt.Errorf("error al leer los directorios de Java: %v", err)
	}

	if javaVersionFolder == "" {
		return "", fmt.Errorf("no se encontró la carpeta de versión de Java en la ruta '%s'", javaPath)
	}

	return javaVersionFolder, nil
}

const (
	delayedAutostartValue = 1
	registryPath          = `SYSTEM\CurrentControlSet\Services\AgentScannerDoc`
)

func main() {
	svcConfig := &service.Config{
		Name:        "AgentScannerDoc",
		DisplayName: "AgentScannerDoc",
		Description: "Service to start the document scanner agent.",
	}
	// Crear el servicio
	prg := &myService{}

	err := prg.setupLogger()
	if err != nil {
		prg.log.WithError(err).Fatal("Error al configurar el logger:", err)
		return
	}

	s, err := service.New(prg, svcConfig)
	if err != nil {
		prg.log.WithError(err).Fatal("Error creating service:", err)
	}

	// Configurar el tipo de inicio como "Automatic (Delayed Start)"
	key, _, err := registry.CreateKey(registry.LOCAL_MACHINE, registryPath, registry.WRITE|registry.CREATE_SUB_KEY)
	if err != nil {
		prg.log.WithError(err).Fatal("Error al abrir o crear la clave del registro")
		return
	}
	defer key.Close()

	// Change the value of "DelayedAutostart" field in the registry to "1" (Automatic Delayed Start)
	if err := key.SetDWordValue("DelayedAutostart", delayedAutostartValue); err != nil {
		prg.log.WithError(err).Fatal("Error al configurar el tipo de inicio del servicio")
		return
	}

	// Detectar señales de interrupción para detener el servicio
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-sigCh
		// Detener el servicio
		if err := s.Stop(); err != nil {
			prg.log.WithError(err).Fatal("Error al detener el service")
		}
	}()

	//verificar si trae la opcion de iniciar el servicio
	if len(os.Args) > 1 {
		if os.Args[1] == "install" {
			err := s.Install()
			if err != nil {
				prg.log.WithError(err).Fatal("Error al instalar el servicio:", err)
			}
			prg.log.Info("Servicio instalado correctamente.")
			return
		}
	}

	// Si no es interactivo, inicia el servicio.
	err = s.Run()
	if err != nil {
		prg.log.WithError(err).Fatal("Error al corrrer el service")
	}
}

func getConfigString(key string) string {
	return viper.GetString(key)
}

func getConfigInt(key string) int {
	return viper.GetInt(key)
}

func getConfigBool(key string) bool {
	return viper.GetBool(key)
}

type ResponseScannerUnJam struct {
	Message string `json:"message"`
}

func (s *myService) handlerScannerUnjam(w http.ResponseWriter, r *http.Request) {
	enableCors(&w)

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	searchString := "scannerdoc"
	err := getJavaProcessIDs(searchString)

	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
	}
	// Crear una estructura de respuesta
	responseData := ResponseScannerUnJam{
		Message: "El escáner se liberó",
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(responseData)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
	}
	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
	}
}

func getJavaProcessIDs(searchString string) error {
	// Nombre del proceso que queremos encontrar (sin la extensión .exe)
	processName := "java"

	pids, err := getProcessIDs(processName)
	if err != nil {
		return err
	}

	for _, pid := range pids {
		pidStr := strings.TrimSpace(pid)
		if err := killJavaProcessIDs(pidStr, searchString); err != nil {
			return err
		}
	}

	return nil
}

// getProcessIDs retrieves the process IDs for a given process name using PowerShell
func getProcessIDs(processName string) ([]string, error) {
	command := fmt.Sprintf(`Get-Process -Name %s | Select-Object -ExpandProperty Id`, processName)
	output, err := executeCommand(command)
	if err != nil {
		return nil, err
	} else {
		return strings.Split(strings.TrimSpace(output), "\n"), nil
	}
}

// executeCommand runs a PowerShell command and returns the output or an error
func executeCommand(command string) (string, error) {
	cmd := exec.Command("powershell", "-Command", command)
	output, err := cmd.CombinedOutput()
	if err != nil {
		if strings.Contains(string(output), "ObjectNotFound") {
			return "", nil
		}
		return "", fmt.Errorf("error ejecutando el comando: %w, salida: %s", err, string(output))
	}
	return string(output), nil
}

func killJavaProcessIDs(pidStr string, searchString string) error {
	if pidStr != "" {
		pid, err := strconv.Atoi(pidStr)
		if err != nil {
			return fmt.Errorf("error convirtiendo la cadena a entero: %v", err)
		}

		cmdline, err := GetCommandLine(pid)
		if err != nil {
			return fmt.Errorf("error obteniendo la línea de comandos: %v", err)
		}

		if ContainsSubstring(cmdline, searchString) {
			if err := killPID(pid); err != nil {
				return fmt.Errorf("error al matar el proceso: %v", err)
			}
		}
	}

	return nil
}

func killPID(pid int) error {
	// Construir el comando taskkill
	cmd := exec.Command("taskkill", "/F", "/PID", fmt.Sprint(pid))
	// Ejecutar el comando
	err := cmd.Run()
	if err != nil {
		return fmt.Errorf("error al ejecutar taskkill %v", err)
	}
	return nil
}

// GetCommandLine obtiene el comando de línea de comandos para un proceso dado.
func GetCommandLine(pid int) (string, error) {
	// Reemplaza con el ID del proceso que deseas inspeccionar
	command := fmt.Sprintf(`(Get-CimInstance Win32_Process -Filter "ProcessId=%d").CommandLine`, pid)

	// Crear el comando usando 'powershell.exe'
	cmd := exec.Command("powershell", "-Command", command)

	// Capturar la salida del comando
	output, err := cmd.CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("error ejecutando el comando %v", err)
	}

	// Convertir la salida a string
	outputStr := string(output)
	return outputStr, nil
}

// ContainsSubstring verifica si una cadena contiene una subcadena específica.
func ContainsSubstring(s, substring string) bool {
	return strings.Contains(strings.ToLower(s), strings.ToLower(substring))
}
