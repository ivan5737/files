package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"strings"
	"syscall"
	"time"

	"github.com/kardianos/service"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"golang.org/x/sys/windows/registry"
	"gopkg.in/natefinch/lumberjack.v2"
	"gopkg.in/yaml.v2"
)

// Crear una estructura para almacenar la configuración
var config *Config

type Config struct {
	HTTP HTTPConfig `yaml:"tLShttp"`
}

type HTTPConfig struct {
	HTTPPort string `yaml:"httpPort"`
	CertFile string `yaml:"certFile"`
	KeyFile  string `yaml:"keyFile"`
}

type ScannerDocData struct {
	ScannerDoc []string `json:"scannerDoc"`
}

// ErrorResponse representa la estructura JSON para los mensajes de error
type ErrorResponse struct {
	Error string `json:"Error"`
}

type myService struct {
	log        *logrus.Logger
	logFile    *lumberjack.Logger
	stopCh     chan struct{}
	httpServer *http.Server
}

// funcion start lista manda llamar la funcion de setupLogger y RUN
func (s *myService) Start(svc service.Service) error {
	s.stopCh = make(chan struct{})
	err := s.setupLogger()
	if err != nil {
		return err
	}

	// Inicia el servidor HTTP aquí
	go s.run()
	return nil
}

// configuracion de log lista para ProgramFiles(x86)
func (s *myService) setupLogger() error {

	viper.SetConfigName("configLog")
	viper.SetConfigType("yaml")
	viper.AddConfigPath(filepath.Join(os.Getenv("ProgramFiles(x86)"), "\\PinPad\\P400CommandoLine\\config\\logs"))

	//viper.Debug()
	err := viper.ReadInConfig()
	if err != nil {
		return err
	}

	s.log = logrus.New()

	s.logFile = &lumberjack.Logger{
		Filename:   getConfigString("log.file.filename"),
		MaxSize:    getConfigInt("log.file.maxSize"),    // MB
		MaxBackups: getConfigInt("log.file.maxBackups"), // Max number of backups
		MaxAge:     getConfigInt("log.file.maxAge"),     // Days
		Compress:   getConfigBool("log.file.compress"),
	}

	s.log.SetOutput(s.logFile)

	// Configurar el nivel de log
	level, err := logrus.ParseLevel(getConfigString("log.level"))
	if err != nil {
		s.log.WithError(err).Fatal("Error al configurar el nivel de log")
	}

	s.log.SetLevel(level)

	// Formato del log en formato JSON para logs estructurados
	s.log.SetFormatter(&logrus.JSONFormatter{})

	return nil
}

// funcion run lista
func (s *myService) run() {
	s.log.Info("Service running...")

	//load file properties
	loadFileProperties(s)

	s.initHTTPServer()
	<-s.stopCh
}

func (s *myService) initHTTPServer() {
	// Inicializa el servidor HTTP aquí
	port := config.HTTP.HTTPPort
	certFile := config.HTTP.CertFile
	keyFile := config.HTTP.KeyFile

	//http.HandleFunc("/pinpad", s.handlerPinPad)
	http.HandleFunc("/pinpad/about", s.handlerPinPadAbout)
	http.HandleFunc("/pinpad/readcard", s.handlerPinPadReadCard)
	http.HandleFunc("/pinpad/validationcard", s.handlerPinPadValidationCard)
	http.HandleFunc("/pinpad/validationemv", s.handlerPinPadValidationEmv)
	http.HandleFunc("/pinpad/validationotp", s.handlerPinPadValidationOtp)
	http.HandleFunc("/pinpad/validationqr", s.handlerPinPadValidationQr)
	http.HandleFunc("/pinpad/pinblock", s.handlerPinPadPinBlock)
	http.HandleFunc("/pinpad/mensaje", s.handlerPinPadMessage)
	// Cargar certificado y clave privada con contraseña
	cert, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err != nil {
		s.log.WithError(err).Fatal(err)
	}

	// Configuración TLS con contraseña
	tlsConfig := &tls.Config{
		Certificates: []tls.Certificate{cert},
	}

	// Función para proporcionar la contraseña de la clave privada
	tlsConfig.GetClientCertificate = func(unused *tls.CertificateRequestInfo) (*tls.Certificate, error) {
		return &cert, nil
	}

	s.httpServer = &http.Server{
		Addr:      ":" + port,
		Handler:   nil, // Usa nil para el enrutador predeterminado (http.DefaultServeMux)
		TLSConfig: tlsConfig,
	}

	go func() {
		if err := s.httpServer.ListenAndServeTLS("", ""); err != nil {
			s.log.WithError(err).Fatal(err)
		}
	}()
}

func (s *myService) Stop(svc service.Service) error {
	close(s.stopCh)
	s.log.Info("Stopping service...")
	if s.logFile != nil {
		err := s.logFile.Close()
		if err != nil {
			s.log.WithError(err).Error("error al cerrar archivo log")
		}
	}

	// Detener el servidor HTTP
	if s.httpServer != nil {
		if err := s.httpServer.Shutdown(nil); err != nil {
			s.log.WithError(err).Error("Error al detener el servidor HTTP")
		}
	}

	// Realiza cualquier limpieza necesaria antes de detener el servicio
	return nil
}

type OutPutActions struct {
	Status string `json:"status"`
	Code   string `json:"code"`
}

type OutPutAbout struct {
	SerialNumber string `json:"serial_number"`
	Modelo       string `json:"modelo"`
	Marca        string `json:"marca"`
	Version      string `json:"version"`
}

type OutPutRead struct {
	Code        string `json:"code"`
	Status      string `json:"status"`
	Pan         string `json:"pan"`
	Name        string `json:"nombre"`
	Validation  string `json:"validation"`
	DateExpired string `json:"dateExpired"`
}

type OutPutValidationCard struct {
	Code        string `json:"code"`
	Status      string `json:"status"`
	Readingtype string `json:"readingtype"`
}

type OutPutValidationOtp struct {
	Status string `json:"status"`
	Code   string `json:"code"`
	Num    string `json:"num"`
}

type OutPutValidationEmv struct {
	Code        string `json:"code"`
	Status      string `json:"status"`
	Readingtype string `json:"readingtype"`
	B2          string `json:"B2"`
	B3          string `json:"B3"`
	B4          string `json:"B4"`
}

type OutPutValidationQr struct {
	Status string `json:"status"`
	Code   string `json:"code"`
}

type OutPutPinBlock struct {
	Code      string `json:"code"`
	PinBlock  string `json:"pinblock"`
	StatusCmd string `json:"status_cmd"`
}

type OutPutMessage struct {
	Status string `json:"status"`
	Code   string `json:"code"`
}

// Constante Nombre del ejecutable
const executableName = "CitiP400CommandLine.exe"

func (s *myService) handlerPinPad(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodGet {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	//bucle para verificar que todos los parametros esten completos

	params := r.URL.Query()
	// Accede a un parámetro específico
	action := params.Get("action")
	if action == "" {
		s.handleError(w, fmt.Errorf("el parámetro %s es requerido", action))
		return
	}

	isMock := params.Get("isMock")
	if isMock == "" {
		isMock = "false"
	}

	requestData := map[string]interface{}{
		"action": action,
		"isMock": isMock,
	}

	var parsedOutputActions OutPutActions
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := callActions(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutputActions)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutputActions = OutPutActions{
			Status: "Exitosa",
			Code:   "00",
		}
	}

	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutputActions)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadAbout(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()
	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodGet {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	// get parameters
	queryParams := r.URL.Query()
	isMock := queryParams.Get("isMock")

	if isMock == "" {
		isMock = "false"
	}

	requestData := map[string]interface{}{
		"action": "about",
		"isMock": isMock,
	}

	var parsedOutputAbout OutPutAbout
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := callActions(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutputAbout)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutputAbout = OutPutAbout{
			SerialNumber: "803-611-495",
			Modelo:       "P400",
			Marca:        "Verifone",
			Version:      "VFP400V.14",
		}
	}

	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutputAbout)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadReadCard(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	var requestData map[string]interface{}
	decoder := json.NewDecoder(r.Body)
	errr := decoder.Decode(&requestData)
	if errr != nil {
		s.handleError(w, fmt.Errorf("%w", errr))
		return
	}

	var parsedOutputRead OutPutRead
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := s.callCommands(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutputRead)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutputRead = OutPutRead{
			Code:        "00",
			Status:      "Exitosa",
			Pan:         "4169160890077960",
			Name:        "",
			Validation:  "1",
			DateExpired: "2801",
		}
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutputRead)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadValidationCard(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	var requestData map[string]interface{}
	decoder := json.NewDecoder(r.Body)
	errr := decoder.Decode(&requestData)
	if errr != nil {
		s.handleError(w, fmt.Errorf("%w", errr))
		return
	}

	var parsedOutputValidationCard OutPutValidationCard
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := s.callCommands(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutputValidationCard)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutputValidationCard = OutPutValidationCard{
			Code:        "00",
			Status:      "Exitosa",
			Readingtype: "1",
		}
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutputValidationCard)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadValidationEmv(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	var requestData map[string]interface{}
	decoder := json.NewDecoder(r.Body)
	errr := decoder.Decode(&requestData)
	if errr != nil {
		s.handleError(w, fmt.Errorf("%w", errr))
		return
	}

	var parsedOutputValidationEmv OutPutValidationEmv
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := s.callCommands(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutputValidationEmv)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutputValidationEmv = OutPutValidationEmv{
			Code:        "00",
			Status:      "Exitosa",
			Readingtype: "1",
			B2:          "\"ARQC_CRYPT_INFODAT\"80\"TERM_VERIF_RESU\"0880008000\"APLICATION CRYPT\"3B56F0AE205D2381\"AMOUNT_AUTHORIZED\"000000100000\"AMOUNT_OTHER\"000000000000\"APL_INTERCH PROF\"3800\"APL_TRANS_COUNTER\"006D\"TERM_COUNTRY_CODE\"484\"TRANS_CURRE_CODE\"484\"TRANS_DATE\"240701\"TRANS TYPE\"00\"UNPREDIC_NUM\"A925726B\"ISS_APPL DATA_LEN\"40\"ISSUER_APPL DATA\"06001203A4A820FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF",
			B3:          "\"TERM SERIAL_NUM\"62077168\"TERM_CAPABILITY\"E0B0C8\"TERMINAL_TYPE\"22\"APL_VERSION NUM\"009A\"CARDHOL_VER_RES\"010302\"DF-NAME-LGTH\"20\"DEDICAT_FILENAME\"A0000000031010FFFFFFFFFFFFFFFFFF",
			B4:          "\"POINT_ENTRY_MODE\"051\"TER_ENTRY CAPAB\"3\"APPL_PAN_SEQ_NUM\"00",
		}
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutputValidationEmv)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadValidationOtp(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	var requestData map[string]interface{}
	decoder := json.NewDecoder(r.Body)
	errr := decoder.Decode(&requestData)
	if errr != nil {
		s.handleError(w, fmt.Errorf("%w", errr))
		return
	}

	var parsedOutputValidationOtp OutPutValidationOtp
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := s.callCommands(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutputValidationOtp)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutputValidationOtp = OutPutValidationOtp{
			Status: "EXITOSO",
			Code:   "000",
			Num:    "1234567890",
		}
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutputValidationOtp)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadValidationQr(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	var requestData map[string]interface{}
	decoder := json.NewDecoder(r.Body)
	errr := decoder.Decode(&requestData)
	if errr != nil {
		s.handleError(w, fmt.Errorf("%w", errr))
		return
	}

	var parsedOutputValidationQr OutPutValidationQr
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := s.callCommands(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutputValidationQr)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutputValidationQr = OutPutValidationQr{
			Status: "EXITOSO",
			Code:   "000",
		}
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutputValidationQr)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadPinBlock(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	var requestData map[string]interface{}
	decoder := json.NewDecoder(r.Body)
	errr := decoder.Decode(&requestData)
	if errr != nil {
		s.handleError(w, fmt.Errorf("%w", errr))
		return
	}

	var parsedOutPutPinBlock OutPutPinBlock
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := s.callCommands(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutPutPinBlock)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutPutPinBlock = OutPutPinBlock{
			Code:      "00",
			PinBlock:  "9255462392FD6DF222A0FE2E9E5B3A18AE9C62D955CDEC5364BCF56E953CFAF74B52B11615D91D42713F1509AEDA269CAEBD21EF6D4B638A224112C97F47444772B6D57EB247632B4454514B504CFB238E9FEBE37C45A8CCB90743A7C633A14EF2E51D333E0C22656A3C0529020C142FC69C22A4D852E1852F7DFE1C5F39F30B6CC6F7FBC05F32851657F67950CFA668EAEB41C887E72EDE0DA87A0EF26034C7E94298F62100388B9057E4206464CB9C6EB8C5E7718EA04DBAEC55B499E8BA62AD46FCAD130760D3D43F5C98F0956031BFCCDDA72323D981E926D1B6624993060F1A4B453D3CD652F317680747F4EB8D9C9C5F72BE5331BEB6FEBB01D4D15F54",
			StatusCmd: "200",
		}
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutPutPinBlock)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func (s *myService) handlerPinPadMessage(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)
	s.disableComponentHttp()

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
		return
	}

	var requestData map[string]interface{}
	decoder := json.NewDecoder(r.Body)
	errr := decoder.Decode(&requestData)
	if errr != nil {
		s.handleError(w, fmt.Errorf("%w", errr))
		return
	}

	var parsedOutPutMessage OutPutMessage
	s.log.Printf("Request data: %+v", requestData)

	if !isExist("isMock", requestData) {

		output, err := s.callCommands(requestData)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}

		// Parsear la salida JSON en la estructura definida
		err = json.Unmarshal(output, &parsedOutPutMessage)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			return
		}
	} else {
		parsedOutPutMessage = OutPutMessage{
			Code:   "00",
			Status: "Exitosa",
		}
	}
	// Convert the result struct to JSON
	jsonData, err := json.Marshal(parsedOutPutMessage)
	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		return
	}

	// Set the response headers
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	// Write the JSON response
	_, err = w.Write(jsonData)
	if err != nil {
		s.log.Println(err)
		return
	}
}

func enableCors(w *http.ResponseWriter) {
	(*w).Header().Set("Access-Control-Allow-Origin", "*")
	(*w).Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS, POST")
	(*w).Header().Set("Access-Control-Allow-Headers", "Origin, Content-Type")
	(*w).Header().Set("Access-Control-Max-Age", "2147483647")
}

func (s *myService) disableComponentHttp() {
	//si la salida de la verificacion de si existe el proceso es 0 quiere decir que no existe el proceso y si es diferente de 0 es por que si existe
	if processExists() != 0 {
		url := "http://127.0.0.1:83/pinpad/desactivar" // Cambia esto a tu URL real
		client := &http.Client{
			Timeout: 3 * time.Second, // Establece un tiempo de espera de 3 segundos
		}
		// Crea una solicitud POST vacía
		req, err := http.NewRequest("POST", url, nil)
		if err != nil {
			s.log.Printf("Error al crear la solicitud para apagar el servicio no seguro: %+v", err)
			return
		}

		// Agrega encabezados personalizados si es necesario
		req.Header.Set("Content-Type", "application/json")

		// Realiza la solicitud
		resp, err := client.Do(req)
		if err != nil {
			s.log.Printf("Error al enviar la solicitud para apagar el servicio no seguro: %+v", err)
			return
		}
		defer resp.Body.Close()
	}
}

func processExists() int {
	// Command to execute the WMIC command
	//cmd := exec.Command("WMIC", "process", "where", "name='VerifoneP400API'", "get", "processid")
	processName := "VerifoneP400API"

	// Comando de PowerShell para obtener el PID del proceso
	command := fmt.Sprintf(`Get-Process -Name %s -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id`, processName)

	// Crear el comando usando 'powershell.exe'
	cmd := exec.Command("powershell", "-Command", command)

	// Run the command and capture the output
	output, err := cmd.CombinedOutput()
	if err != nil {
		return 0
	}

	// Convertir la salida a una cadena y limpiar espacios en blanco
	pid := strings.TrimSpace(string(output))
	if pid == "" {
		return 0
	} else {
		return 1
	}
}

// Listo cargar archivo de propiedades desde ProgramFiles(x86) env
func loadFileProperties(s *myService) {
	// Leer el contenido del archivo de configuración
	data, err := os.ReadFile(filepath.Join(os.Getenv("ProgramFiles(x86)"), "\\PinPad\\P400CommandoLine\\config\\properties\\PinPadProperties.yaml"))
	if err != nil {
		s.log.WithError(err).Fatal("Error al leer el archivo de configuración")
	}
	// Decodificar el archivo YAML en la estructura
	err = yaml.Unmarshal(data, &config)
	if err != nil {
		s.log.WithError(err).Fatal("Error al decodificar el archivo YAML")
	}
	config.HTTP.CertFile = os.ExpandEnv(config.HTTP.CertFile)
	config.HTTP.KeyFile = os.ExpandEnv(config.HTTP.KeyFile)
}

func (s *myService) handleError(w http.ResponseWriter, err error) {
	s.log.WithError(err).Error("Error interno del servidor")
	// Cast the error to string
	errorString := err.Error()
	// Crear una estructura ErrorResponse
	errorResponse := ErrorResponse{
		Error: errorString,
	}

	// Convert the result struct to JSON
	jsonData, err := json.Marshal(errorResponse)
	if err != nil {
		s.log.WithError(err).Error("Error interno del servidor")
	}

	// Serializar la estructura a JSON y escribir en el cuerpo de la respuesta
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusInternalServerError)
	w.Write(jsonData)
}

const (
	delayedAutostartValue = 1
	registryPath          = `SYSTEM\CurrentControlSet\Services\AgentServicePinPad`
)

func main() {
	svcConfig := &service.Config{
		Name:        "AgentServicePinPad",
		DisplayName: "AgentServicePinPad",
		Description: "Service to start the pin pad agent.",
	}
	// Crear el servicio
	prg := &myService{}

	err := prg.setupLogger()
	if err != nil {
		prg.log.WithError(err).Fatal("Error al configurar el logger:", err)
		return
	}

	s, err := service.New(prg, svcConfig)
	if err != nil {
		prg.log.WithError(err).Fatal("Error creating service:", err)
	}

	// Configurar el tipo de inicio como "Automatic (Delayed Start)"
	key, _, err := registry.CreateKey(registry.LOCAL_MACHINE, registryPath, registry.WRITE|registry.CREATE_SUB_KEY)
	if err != nil {
		prg.log.WithError(err).Fatal("Error al abrir o crear la clave del registro")
		return
	}
	defer key.Close()

	// Change the value of "DelayedAutostart" field in the registry to "1" (Automatic Delayed Start)
	if err := key.SetDWordValue("DelayedAutostart", delayedAutostartValue); err != nil {
		prg.log.WithError(err).Fatal("Error al configurar el tipo de inicio del servicio")
		return
	}

	// Detectar señales de interrupción para detener el servicio
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-sigCh
		// Detener el servicio
		if err := s.Stop(); err != nil {
			prg.log.WithError(err).Fatal("Error al detener el service")
		}
	}()

	//verificar si trae la opcion de iniciar el servicio
	if len(os.Args) > 1 {
		if os.Args[1] == "install" {
			err := s.Install()
			if err != nil {
				prg.log.WithError(err).Fatal("Error al instalar el servicio:", err)
			}
			prg.log.Info("Servicio instalado correctamente.")
			return
		}
	}

	// Si no es interactivo, inicia el servicio.
	err = s.Run()
	if err != nil {
		prg.log.WithError(err).Fatal("Error al corrrer el service")
	}
}

func getConfigString(key string) string {
	return viper.GetString(key)
}

func getConfigInt(key string) int {
	return viper.GetInt(key)
}

func getConfigBool(key string) bool {
	return viper.GetBool(key)
}

func isExist(key string, requestData map[string]interface{}) bool {
	val, ok := requestData[key]
	if !ok {
		return false
	}

	switch v := val.(type) {
	case bool:
		return v
	case string:
		// Aquí puedes manejar casos especiales si es necesario
		return v == "true" || v == "1"
	default:
		return false
	}
}

func callActions(requestData map[string]interface{}) ([]byte, error) {
	// Combinar la ruta con el nombre del ejecutable
	executableFullPath := filepath.Join(os.Getenv("ProgramFiles(x86)"), "\\PinPad\\P400CommandoLine\\"+executableName)

	args := []string{
		requestData["action"].(string),
	}

	// se ejecuta el ejecutable enviando los parametros del accion
	cmd := exec.Command(
		executableFullPath, args...)

	//run with hide window of java
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true,
	}

	// Capture the command's output and error
	output, err := cmd.CombinedOutput()
	output = getTextInsideCommand(string(output))
	return output, err
}

func (s *myService) callCommands(requestData map[string]interface{}) ([]byte, error) {
	// Combinar la ruta con el nombre del ejecutable
	executableFullPath := filepath.Join(os.Getenv("ProgramFiles(x86)"), "\\PinPad\\P400CommandoLine\\"+executableName)

	var cmd *exec.Cmd

	if code, ok := requestData["command"].(string); ok {
		switch code {
		case "lectura":
			args := []string{
				requestData["command"].(string),
				requestData["timeout"].(string),
				requestData["validationtype"].(string),
				requestData["date"].(string),
			}

			cmd = exec.Command(
				executableFullPath, args...)

		case "validation":
			args := []string{
				requestData["command"].(string),
				requestData["timeout"].(string),
				requestData["amount"].(string),
				requestData["cardnumber"].(string),
				requestData["clientname"].(string),
				requestData["address"].(string),
				requestData["validationtype"].(string),
				requestData["balance"].(string),
			}

			cmd = exec.Command(
				executableFullPath, args...)

		case "validationemv":
			args := []string{
				requestData["command"].(string),
				requestData["timeout"].(string),
				requestData["amount"].(string),
				requestData["cardnumber"].(string),
				requestData["clientname"].(string),
				requestData["validationtype"].(string),
			}

			cmd = exec.Command(
				executableFullPath, args...)
		case "otp":
			args := []string{
				requestData["command"].(string),
				requestData["message1"].(string),
				requestData["clientname"].(string),
				requestData["operationdate"].(string),
				requestData["timeout"].(string),
				requestData["optsize"].(string),
				requestData["message2"].(string), // Corregido
			}

			cmd = exec.Command(
				executableFullPath, args...)
		case "validationqr":
			args := []string{
				requestData["command"].(string),
				requestData["validationtype"].(string),
				requestData["numortext"].(string),
				requestData["timeout"].(string),
			}

			cmd = exec.Command(
				executableFullPath, args...)
		case "PINblock":
			args := []string{
				requestData["command"].(string),
				requestData["timeout"].(string),
				requestData["typecard"].(string),
				requestData["pan"].(string),
				requestData["minlenpin"].(string),
				requestData["maxlenpin"].(string),
				requestData["modulo"].(string),
				requestData["exponente"].(string),
			}

			cmd = exec.Command(
				executableFullPath, args...)
		case "mensaje":
			args := []string{
				requestData["command"].(string),
				requestData["mensaje"].(string),
				requestData["type"].(string),
			}

			cmd = exec.Command(
				executableFullPath, args...)
		default:
			s.log.Info("commando no reconocido:", code)
		}
	} else {
		s.log.Info("'command' no es un string válido")
	}

	//run with hide window of java
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true,
	}

	// Capture the command's output and error
	output, err := cmd.CombinedOutput()
	output = getTextInsideCommand(string(output))
	return output, err
}

func getTextInsideCommand(completeString string) []byte {
	// regexp
	re := regexp.MustCompile(`\{([^{}]+)\}`)
	match := re.FindString(completeString)
	// Verificar si se encontraron coincidencias
	return []byte(match)
}
