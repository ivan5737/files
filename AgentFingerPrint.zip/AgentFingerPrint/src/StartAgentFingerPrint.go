package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"strings"
	"syscall"

	"github.com/kardianos/service"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"golang.org/x/sys/windows/registry"
	"gopkg.in/natefinch/lumberjack.v2"
	"gopkg.in/yaml.v2"
)

// variable con el nombre de la carpeta de ScannerKit
const scannerKitFolderName string = "ScannerKit"

// variable global de log para utilizarlo en cualquiera de nuestras funciones
var log *logrus.Logger

// Crear una estructura para almacenar la configuración
var config *Config

type Config struct {
	HTTP    HTTPConfig    `yaml:"tLShttp"`
	Folders FoldersConfig `yaml:"folders"`
	Paths   PathsConfig   `yaml:"paths"`
}

type HTTPConfig struct {
	HTTPPort string `yaml:"httpPort"`
	CertFile string `yaml:"certFile"`
	KeyFile  string `yaml:"keyFile"`
}

type FoldersConfig struct {
	ScannerKit   string `yaml:"scannerKit"`
	Certificates string `yaml:"certificates"`
	JavaVersion  string `yaml:"javaVersionFolder"`
}

type PathsConfig struct {
	PatResources        string `yaml:"patResources"`
	JarPath             string `yaml:"jarPath"`
	JarPathDependencies string `yaml:"jarPathDependencies"`
	ProgramFilesx86or64 string `yaml:"programFilesx86or64Path"`
	ProgramData         string `yaml:"programDataPath"`
}

type FingerprintData struct {
	Fingerprint string `json:"Fingerprint"`
}

// ErrorResponse representa la estructura JSON para los mensajes de error
type ErrorResponse struct {
	Error string `json:"Error"`
}

type program struct {
	service service.Service
}

type myService struct {
	log        *logrus.Logger
	logFile    *lumberjack.Logger
	stopCh     chan struct{}
	httpServer *http.Server
}

func (s *myService) Start(svc service.Service) error {
	s.stopCh = make(chan struct{})
	err := s.setupLogger()
	if err != nil {
		return err
	}

	// Inicia el servidor HTTP aquí
	go s.run()
	return nil
}

func (s *myService) setupLogger() error {

	viper.SetConfigName("configLog")
	viper.SetConfigType("yaml")
	viper.AddConfigPath(filepath.Join(os.Getenv("ProgramData"), scannerKitFolderName+"\\AgentFingerPrint\\config"))

	//viper.Debug()
	err := viper.ReadInConfig()
	if err != nil {
		return err
	}

	s.log = logrus.New()

	s.logFile = &lumberjack.Logger{
		Filename:   getConfigString("log.file.filename"),
		MaxSize:    getConfigInt("log.file.maxSize"),    // MB
		MaxBackups: getConfigInt("log.file.maxBackups"), // Max number of backups
		MaxAge:     getConfigInt("log.file.maxAge"),     // Days
		Compress:   getConfigBool("log.file.compress"),
	}

	s.log.SetOutput(s.logFile)

	// Configurar el nivel de log
	level, err := logrus.ParseLevel(getConfigString("log.level"))
	if err != nil {
		s.log.WithError(err).Fatal("Error al configurar el nivel de log")
	}

	s.log.SetLevel(level)

	// Formato del log en formato JSON para logs estructurados
	s.log.SetFormatter(&logrus.JSONFormatter{})

	return nil
}

func (s *myService) run() {
	s.log.Info("Service running...")

	//load file properties
	loadFileProperties(s)

	s.initHTTPServer()
	<-s.stopCh
}

func (s *myService) initHTTPServer() {
	/*
		// Crear un nuevo enrutador Gorilla Mux
		r := mux.NewRouter()

		// Configurar el middleware CORS con opciones que permiten cualquier origen
		corsMiddleware := func(next http.Handler) http.Handler {
			return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Access-Control-Allow-Origin", "*")
				w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
				w.Header().Set("Access-Control-Allow-Headers", "Origin, Content-Type, Authorization")
				next.ServeHTTP(w, r)
			})
		}

		// Aplicar el middleware CORS al enrutador Gorilla Mux
		r.Use(corsMiddleware)

		// Registrar la ruta para "/fingerPrint"
		r.HandleFunc("/fingerPrint", s.handler).Methods("GET")
		r.HandleFunc("/fingerPrint", s.handleOPTIONS).Methods("OPTIONS")
	*/
	// Inicializa el servidor HTTP aquí
	port := config.HTTP.HTTPPort
	certFile := config.HTTP.CertFile
	keyFile := config.HTTP.KeyFile

	http.HandleFunc("/fingerPrint", s.handler)

	s.httpServer = &http.Server{
		Addr:    ":" + port,
		Handler: nil, // Usa nil para el enrutador predeterminado (http.DefaultServeMux)
	}

	go func() {
		if err := s.httpServer.ListenAndServeTLS(certFile, keyFile); err != nil {
			s.log.WithError(err).Fatal(err)
		}
	}()
}

func (s *myService) Stop(svc service.Service) error {
	close(s.stopCh)
	s.log.Info("Stopping service...")
	if s.logFile != nil {
		err := s.logFile.Close()
		if err != nil {
			s.log.WithError(err).Error("error al cerrar archivo log")
		}
	}

	// Detener el servidor HTTP
	if s.httpServer != nil {
		if err := s.httpServer.Shutdown(nil); err != nil {
			s.log.WithError(err).Error("Error al detener el servidor HTTP")
		}
	}

	// Realiza cualquier limpieza necesaria antes de detener el servicio
	return nil
}
func (s *myService) handleOPTIONS(w http.ResponseWriter, r *http.Request) {
	// En una solicitud OPTIONS, simplemente respondemos con los encabezados CORS permitidos
	w.WriteHeader(http.StatusOK)
}

func (s *myService) handler(w http.ResponseWriter, r *http.Request) {

	enableCors(&w)

	// Verificar si la solicitud es de tipo OPTIONS (preflight)
	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	requiredParams := []string{"template", "timeout", "threshold", "isMock", "logsEnabled"}

	//bucle para verificar que todos los parametros esten completos
	for _, param := range requiredParams {
		value := r.URL.Query().Get(param)
		if value == "" {
			s.handleError(w, fmt.Errorf("el parámetro %s es requerido", param))
			//return fmt.Errorf(`{"Error":El parámetro "%s"  es requerido }`, param)
		}
	}

	// get parameters
	queryParams := r.URL.Query()
	template := queryParams.Get("template")
	timeout := queryParams.Get("timeout")
	threshold := queryParams.Get("threshold")
	isMock := queryParams.Get("isMock")
	logsEnabled := queryParams.Get("logsEnabled")

	// JAR file arguments
	jarArgs := []string{template, timeout, threshold, isMock, logsEnabled}

	// Path to the Java executable
	javaPathFolder, errjava := getJavaForlderPath()
	if errjava != nil {
		s.handleError(w, fmt.Errorf("%w", errjava))
		//return fmt.Errorf(`{"Error":"%s"}`, errjava)
	}

	javaPath := javaPathFolder + "\\bin\\java.exe"

	if directoryNoExists(config.Paths.PatResources) {
		s.handleError(w, fmt.Errorf("el directorio %s no existe", config.Paths.PatResources))
		//return fmt.Errorf(`{"Error":"El directorio %s no existe."}`, config.Paths.PatResources)
	}

	cmdArgs := []string{"-cp", config.Paths.PatResources + config.Paths.JarPathDependencies, "-jar", config.Paths.PatResources + config.Paths.JarPath}
	cmdArgs = append(cmdArgs, jarArgs...)
	cmd := exec.Command(javaPath, cmdArgs...)

	//run with hide window of java
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true,
	}

	// Capture the command's output and error
	output, err := cmd.CombinedOutput()

	if err != nil {
		s.handleError(w, fmt.Errorf("%w", err))
		//return fmt.Errorf(`{"Error":"%s"}`, err)
	}

	//validamos si en la variable de salida de la ejecucion del jar hay algun error
	if strings.Contains(string(output), "\"Error\"") {
		s.handleError(w, fmt.Errorf("%s", getTextInside(string(output))))
		//return fmt.Errorf(`{"Error":"%s"}`, getTextInside(string(output)))
	} else {
		// Create a struct with the desired JSON structure
		data := FingerprintData{
			Fingerprint: getTextInside(string(output)),
		}
		// Convert the result struct to JSON
		jsonData, err := json.Marshal(data)
		if err != nil {
			s.handleError(w, fmt.Errorf("%w", err))
			//return fmt.Errorf(`{"Error":"%s"}`, err)
		}
		// Set the response headers
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)

		// Write the JSON response
		_, err = w.Write(jsonData)
		if err != nil {
			s.log.Println(err)
		}
	}

	//return nil
}

func enableCors(w *http.ResponseWriter) {
	(*w).Header().Set("Access-Control-Allow-Origin", "*")
	(*w).Header().Set("Access-Control-Allow-Methods", "GET")
	(*w).Header().Set("Access-Control-Allow-Headers", "Content-Type")
}

func directoryNoExists(directoryPath string) bool {
	info, err := os.Stat(directoryPath)
	if os.IsNotExist(err) {
		return true // El directorio no existe
	}
	if err != nil {
		return true
	}
	return !info.IsDir()
}

// load file properties from ScannerKitFolder in Program Data

func loadFileProperties(s *myService) {
	// Leer el contenido del archivo de configuración
	data, err := ioutil.ReadFile(filepath.Join(os.Getenv("ProgramData"), scannerKitFolderName+"\\AgentFingerPrint\\config\\StartAgentFingerPrintProperties.yaml"))
	if err != nil {
		s.log.WithError(err).Fatal("Error al leer el archivo de configuración")
	}
	// Decodificar el archivo YAML en la estructura
	err = yaml.Unmarshal(data, &config)
	if err != nil {
		s.log.WithError(err).Fatal("Error al decodificar el archivo YAML")
	}
}

/*
func (s *myService) errorHandler(handler func(http.ResponseWriter, *http.Request) error) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		err := handler(w, r)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			//se guarda en el log
			s.log.WithError(err).Error("Error en el handler")
		}
	}
}*/

func (s *myService) handleError(w http.ResponseWriter, err error) {
	s.log.WithError(err).Error("Error interno del servidor")
	// Cast the error to string
	errorString := err.Error()
	// Crear una estructura ErrorResponse
	errorResponse := ErrorResponse{
		Error: errorString,
	}

	// Convert the result struct to JSON
	jsonData, err := json.Marshal(errorResponse)
	if err != nil {
		s.log.WithError(err).Error("Error interno del servidor")
	}

	// Serializar la estructura a JSON y escribir en el cuerpo de la respuesta
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusInternalServerError)
	w.Write(jsonData)
}

func getTextInside(completeString string) string {
	// regexp
	re := regexp.MustCompile(`\{([^{}]+)\}`)

	// Buscar coincidencias en la cadena
	matches := re.FindStringSubmatch(completeString)

	// Verificar si se encontraron coincidencias
	if len(matches) > 1 {
		//return matches[1]
		return sanitizeJSONString(matches[1])
	} else {
		return completeString
	}

}

func sanitizeJSONString(jsonStr string) string {

	jsonStr = strings.Replace(jsonStr, "\n\t\"Fingerprint\": ", "", 1)
	jsonStr = strings.Replace(jsonStr, "\"", "", -1)
	jsonStr = strings.Replace(jsonStr, "\n", "", -1)
	jsonStr = strings.Replace(jsonStr, "\tError:", "", -1)
	// Remover las comillas al inicio y al final del valor de Fingerprint
	jsonStr = strings.Trim(jsonStr, "\"")

	return jsonStr
}

func getJavaForlderPath() (string, error) {
	// obtiene el java path si existe en la ProgramFilesx86or64
	javaPath := filepath.Join(os.Getenv(config.Paths.ProgramFilesx86or64), "Java")

	// Verifica si el directorio existe
	_, err := os.Stat(javaPath)
	if err != nil {
		if os.IsNotExist(err) {
			return "", fmt.Errorf("no tienes una instalación de Java  en la carpeta" + os.Getenv(config.Paths.ProgramFilesx86or64))
		}
		return "", fmt.Errorf("error al verificar la existencia de la instalación de Java: %v", err)
	}

	var javaVersionFolder string
	err = filepath.Walk(javaPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() && strings.Contains(info.Name(), config.Folders.JavaVersion) {
			javaVersionFolder = path
			return filepath.SkipDir
		}
		return nil
	})

	if err != nil {
		return "", fmt.Errorf("error al leer los directorios de Java: %v", err)
	}

	if javaVersionFolder == "" {
		return "", fmt.Errorf("no se encontró la carpeta de versión de Java en la ruta '%s'", javaPath)
	}

	return javaVersionFolder, nil
}

const (
	delayedAutostartValue = 1
	registryPath          = `SYSTEM\CurrentControlSet\Services\ScannerKitAgentFingerPrint`
)

func main() {

	svcConfig := &service.Config{
		Name:        "ScannerKitAgentFingerPrint",
		DisplayName: "ScannerKitAgentFingerPrint",
		Description: "Service to start finger print.",
	}

	// Crear el servicio
	prg := &myService{}

	err := prg.setupLogger()
	if err != nil {
		prg.log.WithError(err).Fatal("Error al configurar el logger:", err)
		return
	}

	s, err := service.New(prg, svcConfig)
	if err != nil {
		prg.log.WithError(err).Fatal("Error creating service:", err)
	}

	// Configurar el tipo de inicio como "Automatic (Delayed Start)"
	key, _, err := registry.CreateKey(registry.LOCAL_MACHINE, registryPath, registry.WRITE|registry.CREATE_SUB_KEY)
	if err != nil {
		prg.log.WithError(err).Fatal("Error al abrir o crear la clave del registro")
		return
	}
	defer key.Close()

	// Change the value of "DelayedAutostart" field in the registry to "1" (Automatic Delayed Start)
	if err := key.SetDWordValue("DelayedAutostart", delayedAutostartValue); err != nil {
		prg.log.WithError(err).Fatal("Error al configurar el tipo de inicio del servicio")
		return
	}

	// Detectar señales de interrupción para detener el servicio
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-sigCh
		// Detener el servicio
		if err := s.Stop(); err != nil {
			prg.log.WithError(err).Fatal("Error al detener el service")
		}
	}()

	//verificar si trae la opcion de iniciar el servicio
	if len(os.Args) > 1 {
		if os.Args[1] == "install" {
			err := s.Install()
			if err != nil {
				prg.log.WithError(err).Fatal("Error al instalar el servicio:", err)
			}
			prg.log.Info("Servicio instalado correctamente.")
			return
		}
	}

	// Si no es interactivo, inicia el servicio.
	err = s.Run()
	if err != nil {
		prg.log.WithError(err).Fatal("Error al corrrer el service")
	}
}

func getConfigString(key string) string {
	return viper.GetString(key)
}

func getConfigInt(key string) int {
	return viper.GetInt(key)
}

func getConfigBool(key string) bool {
	return viper.GetBool(key)
}
